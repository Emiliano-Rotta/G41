function Carrito() {


    return (
      <>
        Hola soy Carrito
      </>
    )
  }
  
  export default Carrito