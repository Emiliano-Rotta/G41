function Detalle() {


    return (
      <>
        Hola soy Detalle
      </>
    )
  }
  
  export default Detalle