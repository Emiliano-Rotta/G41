function NotFound() {


    return (
      <>
        404
      </>
    )
  }
  
  export default NotFound