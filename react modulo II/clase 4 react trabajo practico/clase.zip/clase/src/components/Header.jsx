function Header() {


    return (
      <>
        <h2>Pizzeria Mamma Mia</h2>
        <h6>¡Tenemos las mejores pizzas que podrás encontrar!</h6>
      </>
    )
  }
  
  export default Header