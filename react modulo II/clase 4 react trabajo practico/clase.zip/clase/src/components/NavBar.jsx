function NavBar() {


    return (
      <>
        <h2>Pizzería Mamma Mia!</h2>
        <h2> Total: </h2>
      </>
    )
  }
  
  export default NavBar